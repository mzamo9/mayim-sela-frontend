function placeOrder() {
    const loggedIn = sessionStorage.getItem("loggedIn");

    if (!loggedIn) {
        alert("You must log in to place an order!");
        window.location.href = "login.html";
    } else {
        window.location.href = "customer.html";
    }
}

function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const content = document.getElementById("content");

    sidebar.classList.toggle("collapsed");
    content.classList.toggle("expanded");
}



// To place an order (redirect to PHP backend)
function orderProduct(productName) {
    const userId = sessionStorage.getItem("loggedIn");
    if (!userId) {
        alert("You must be logged in to place an order!");
        window.location.href = "login.html";
        return;
    }

    // Redirecting to a PHP order handler
    window.location.href = `php/order.php?product=${encodeURIComponent(productName)}&quantity=1`;
}


