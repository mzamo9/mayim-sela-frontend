<?php
session_start();
include 'db.php';

// Ensure customer is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.html");
    exit();
}

if (isset($_GET['product']) && isset($_GET['quantity'])) {
    $product = $_GET['product'];
    $quantity = intval($_GET['quantity']);
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO orders (user_id, product_name, quantity) VALUES (?, ?, ?)");
    $stmt->bind_param("isi", $user_id, $product, $quantity);
    $stmt->execute();

    header("Location: ../customer.html"); // refresh dashboard
    exit();
} else {
    echo "Invalid order data.";
}
