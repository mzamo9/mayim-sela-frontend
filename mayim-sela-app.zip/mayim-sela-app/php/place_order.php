<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in first.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $product_name = $_POST['product_name'];
    $quantity = intval($_POST['quantity']);

    if (empty($product_name) || $quantity <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid input.']);
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO orders (user_id, product_name, quantity) VALUES (?, ?, ?)");
    $stmt->bind_param("isi", $user_id, $product_name, $quantity);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => '✅ Order placed successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => '❌ Failed to place order.']);
    }

    $stmt->close();
    $conn->close();
}
