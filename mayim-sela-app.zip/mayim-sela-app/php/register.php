<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = trim($_POST['password']);

    if (empty($fullname) || empty($email) || empty($password)) {
        echo "<script>alert('Please fill in all required fields.'); window.location='../register.html';</script>";
        exit();
    }

    // Check if email already exists
    $check = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Email already registered. Please login.'); window.location='../login.html';</script>";
        exit();
    }

    // 🔐 Hash password (secure way)
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (full_name, email, phone, password, role) VALUES (?, ?, ?, ?, 'customer')");
    $stmt->bind_param("ssss", $fullname, $email, $phone, $hashedPassword);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Registration successful! Please log in.'); window.location='../login.html';</script>";
    } else {
        echo "<script>alert('❌ Registration failed. Try again later.'); window.location='../register.html';</script>";
    }

    $stmt->close();
    $check->close();
    $conn->close();
}
