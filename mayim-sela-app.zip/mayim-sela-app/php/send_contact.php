<?php
// Database connection settings
$servername = "localhost";
$username = "root"; // default for XAMPP
$password = ""; // default for XAMPP (empty)
$dbname = "mayim_sela";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data safely
$name = $conn->real_escape_string($_POST['name']);
$email = $conn->real_escape_string($_POST['email']);
$phone = $conn->real_escape_string($_POST['phone']);
$message = $conn->real_escape_string($_POST['message']);

// Insert into database
$sql = "INSERT INTO contact_messages (name, email, phone, message)
        VALUES ('$name', '$email', '$phone', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Thank you! Your message has been sent successfully.'); window.location='../contact.html';</script>";
} else {
    echo "<script>alert('Error: " . $conn->error . "'); window.location='../contact.html';</script>";
}

$conn->close();
