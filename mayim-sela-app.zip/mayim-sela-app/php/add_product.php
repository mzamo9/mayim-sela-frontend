<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $description = $_POST['description'];

    // Handle image upload
    $image_name = $_FILES['image']['name'];
    $target = "../assets/images/" . basename($image_name);
    move_uploaded_file($_FILES['image']['tmp_name'], $target);

    $stmt = $conn->prepare("INSERT INTO inventory (product_name, price, stock, description, image) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sdisi", $product_name, $price, $stock, $description, $image_name);
    $stmt->execute();

    header("Location: ../admin.html");
    exit();
}
