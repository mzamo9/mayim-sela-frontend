<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['staff_id'])) {
    $staff_id = intval($_POST['staff_id']);

    $stmt = $conn->prepare("DELETE FROM users WHERE id=? AND role='staff'");
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();

    header("Location: ../admin.html");
    exit();
}
?>