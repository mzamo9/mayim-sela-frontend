<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $hashedPassword, $role);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        if (password_verify($password, $hashedPassword)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['role'] = $role;

            if ($role === 'customer') header("Location: ../customer.html");
            elseif ($role === 'staff') header("Location: ../staff.html");
            elseif ($role === 'admin') header("Location: ../admin.html");

            exit();
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "No account found with this email!";
    }
}
?>